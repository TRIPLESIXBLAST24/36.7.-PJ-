#include <QApplication>
#include "serverwindow.h"
#include <QStyleFactory>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);


    app.setStyle(QStyleFactory::create("Fusion"));


    app.setApplicationName("STL Chat Server");
    app.setApplicationVersion("1.0");
    app.setOrganizationName("STL Chat");

    ServerWindow window;
    window.show();

    return app.exec();
}

