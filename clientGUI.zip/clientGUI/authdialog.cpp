#include "authdialog.h"
#include <QMessageBox>

AuthDialog::AuthDialog(QWidget *parent)
    : QDialog(parent), isRegisterMode(false) {
    setWindowTitle("Авторизация");
    setModal(true);
    resize(400, 350);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(20, 20, 20, 20);
    
    QLabel* titleLabel = new QLabel("STL Chat", this);
    titleLabel->setStyleSheet("font-size: 18pt; font-weight: bold; color: #2196F3;");
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);
    
    QHBoxLayout* modeLayout = new QHBoxLayout();
    modeLayout->setAlignment(Qt::AlignCenter);
    
    loginRadio = new QRadioButton("Вход", this);
    registerRadio = new QRadioButton("Регистрация", this);
    loginRadio->setChecked(true);
    
    modeLayout->addWidget(loginRadio);
    modeLayout->addWidget(registerRadio);
    mainLayout->addLayout(modeLayout);
    
    connect(loginRadio, &QRadioButton::toggled, this, &AuthDialog::onModeChanged);
    connect(registerRadio, &QRadioButton::toggled, this, &AuthDialog::onModeChanged);
    
    stackWidget = new QStackedWidget(this);
    
    QWidget* loginPage = new QWidget();
    QWidget* registerPage = new QWidget();
    
    stackWidget->addWidget(loginPage);
    stackWidget->addWidget(registerPage);
    
    mainLayout->addWidget(stackWidget);
    
    QVBoxLayout* loginLayout = new QVBoxLayout(loginPage);
    loginLayout->setSpacing(10);
    
    QLabel* loginLabel1 = new QLabel("Логин:", loginPage);
    loginInput = new QLineEdit(loginPage);
    loginInput->setPlaceholderText("Введите логин");
    loginLayout->addWidget(loginLabel1);
    loginLayout->addWidget(loginInput);
    
    QLabel* passwordLabel1 = new QLabel("Пароль:", loginPage);
    passwordInput = new QLineEdit(loginPage);
    passwordInput->setPlaceholderText("Введите пароль");
    passwordInput->setEchoMode(QLineEdit::Password);
    loginLayout->addWidget(passwordLabel1);
    loginLayout->addWidget(passwordInput);
    loginLayout->addStretch();
    
    QVBoxLayout* registerLayout = new QVBoxLayout(registerPage);
    registerLayout->setSpacing(10);
    
    QLabel* loginLabel2 = new QLabel("Логин (3-20 символов):", registerPage);
    registerLoginInput = new QLineEdit(registerPage);
    registerLoginInput->setPlaceholderText("Введите логин");
    registerLayout->addWidget(loginLabel2);
    registerLayout->addWidget(registerLoginInput);
    
    QLabel* passwordLabel2 = new QLabel("Пароль (минимум 6 символов):", registerPage);
    registerPasswordInput = new QLineEdit(registerPage);
    registerPasswordInput->setPlaceholderText("Введите пароль");
    registerPasswordInput->setEchoMode(QLineEdit::Password);
    registerLayout->addWidget(passwordLabel2);
    registerLayout->addWidget(registerPasswordInput);
    
    QLabel* nameLabel = new QLabel("Имя:", registerPage);
    nameInput = new QLineEdit(registerPage);
    nameInput->setPlaceholderText("Введите ваше имя (необязательно)");
    registerLayout->addWidget(nameLabel);
    registerLayout->addWidget(nameInput);
    registerLayout->addStretch();
    
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    QPushButton* okButton = new QPushButton("OK", this);
    QPushButton* cancelButton = new QPushButton("Отмена", this);
    
    okButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #2196F3;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 5px;"
        "    padding: 10px 20px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover { background-color: #1976D2; }"
    );
    
    cancelButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #f44336;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 5px;"
        "    padding: 10px 20px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover { background-color: #d32f2f; }"
    );
    
    buttonLayout->addStretch();
    buttonLayout->addWidget(okButton);
    buttonLayout->addWidget(cancelButton);
    mainLayout->addLayout(buttonLayout);
    
    connect(okButton, &QPushButton::clicked, this, &AuthDialog::onOkClicked);
    connect(cancelButton, &QPushButton::clicked, this, &AuthDialog::onCancelClicked);
    
    loginInput->setFocus();
    onModeChanged();
}

void AuthDialog::onModeChanged() {
    isRegisterMode = registerRadio->isChecked();
    stackWidget->setCurrentIndex(isRegisterMode ? 1 : 0);
}

QString AuthDialog::getLogin() const {
    if (isRegisterMode) {
        return registerLoginInput->text();
    } else {
        return loginInput->text();
    }
}

QString AuthDialog::getPassword() const {
    if (isRegisterMode) {
        return registerPasswordInput->text();
    } else {
        return passwordInput->text();
    }
}

QString AuthDialog::getName() const {
    return nameInput->text();
}

void AuthDialog::onOkClicked() {
    QString login = getLogin();
    QString password = getPassword();
    
    if (login.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Введите логин!");
        return;
    }
    
    if (password.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Введите пароль!");
        return;
    }
    
    if (isRegisterMode) {
        if (login.length() < 3 || login.length() > 20) {
            QMessageBox::warning(this, "Ошибка", "Логин должен быть от 3 до 20 символов!");
            return;
        }
        if (password.length() < 6) {
            QMessageBox::warning(this, "Ошибка", "Пароль должен быть минимум 6 символов!");
            return;
        }
    }
    
    accept();
}

void AuthDialog::onCancelClicked() {
    reject();
}

