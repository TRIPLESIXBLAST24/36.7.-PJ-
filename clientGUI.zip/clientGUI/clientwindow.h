#ifndef CLIENTWINDOW_H
#define CLIENTWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QListWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QLabel>
#include <QSplitter>
#include <QTimer>
#include <QMessageBox>
#include <QGroupBox>
#include <QComboBox>
#include <QMenuBar>
#include <QMenu>
#include <QStatusBar>
#include <QKeyEvent>
#include "chat.h"

class ClientWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit ClientWindow(QWidget *parent = nullptr);
    ~ClientWindow();

private slots:
    void refreshMessages();
    void sendMessage();
    void onUserSelected();
    void sendPrivateMessage();
    void onSearchTextChanged();
    void onMessageTypeChanged();
    void logout();
    void showProfile();
    void manageFriends();

protected:
    bool eventFilter(QObject* obj, QEvent* event) override;

private:
    void setupUI();
    void setupStyles();
    void updateUsersList();
    void updateMessagesDisplay();
    void showErrorMessage(const QString& message);

    Chat* chat;
    QTimer* refreshTimer;
    
    QWidget* centralWidget;
    QHBoxLayout* mainLayout;
    
    QSplitter* mainSplitter;
    QWidget* leftPanel;
    QWidget* rightPanel;
    
    QListWidget* usersList;
    QLabel* userInfoLabel;
    
    QTextEdit* messagesDisplay;
    QLineEdit* messageInput;
    QPushButton* sendButton;
    QComboBox* messageTypeCombo;
    
    QLineEdit* searchInput;
    QComboBox* filterCombo;
    
    QString currentSelectedUser;
    bool isPrivateMode;
};

#endif

