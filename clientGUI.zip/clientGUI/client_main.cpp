#include <QApplication>
#include "clientwindow.h"
#include <QStyleFactory>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    app.setStyle(QStyleFactory::create("Fusion"));
    app.setApplicationName("STL Chat Client");
    app.setApplicationVersion("1.0");
    app.setOrganizationName("STL Chat");
    
    ClientWindow window;
    window.show();
    
    return app.exec();
}

