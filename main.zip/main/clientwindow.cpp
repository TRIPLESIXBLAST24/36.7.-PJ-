#include "clientwindow.h"
#include "connectiondialog.h"
#include "authdialog.h"
#include <QHeaderView>
#include <QDateTime>
#include <QColor>
#include <QScrollBar>
#include <QTextCursor>
#include <QKeyEvent>
#include <QAbstractItemView>
#include <string>
#include <sstream>

ClientWindow::ClientWindow(QWidget *parent)
    : QMainWindow(parent), chat(nullptr), isPrivateMode(false) {
    setupUI();
    setupStyles();
    
    refreshTimer = new QTimer(this);
    connect(refreshTimer, &QTimer::timeout, this, &ClientWindow::refreshMessages);
}

ClientWindow::~ClientWindow() {
    if (chat) {
        chat->disconnectFromServer();
        delete chat;
    }
}

void ClientWindow::setupUI() {
    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);
    
    mainSplitter = new QSplitter(Qt::Horizontal, this);
    
    leftPanel = new QWidget(this);
    leftPanel->setMaximumWidth(250);
    leftPanel->setMinimumWidth(200);
    QVBoxLayout* leftLayout = new QVBoxLayout(leftPanel);
    leftLayout->setContentsMargins(10, 10, 10, 10);
    
    userInfoLabel = new QLabel("Не авторизован", leftPanel);
    userInfoLabel->setStyleSheet("font-weight: bold; font-size: 12pt; padding: 10px;");
    userInfoLabel->setAlignment(Qt::AlignCenter);
    leftLayout->addWidget(userInfoLabel);
    
    QLabel* usersLabel = new QLabel("Пользователи:", leftPanel);
    leftLayout->addWidget(usersLabel);
    
    usersList = new QListWidget(leftPanel);
    usersList->setSelectionMode(QAbstractItemView::SingleSelection);
    connect(usersList, &QListWidget::itemClicked, this, &ClientWindow::onUserSelected);
    leftLayout->addWidget(usersList);
    
    QPushButton* friendsButton = new QPushButton("Друзья", leftPanel);
    QPushButton* profileButton = new QPushButton("Профиль", leftPanel);
    QPushButton* logoutButton = new QPushButton("Выйти", leftPanel);
    
    connect(friendsButton, &QPushButton::clicked, this, &ClientWindow::manageFriends);
    connect(profileButton, &QPushButton::clicked, this, &ClientWindow::showProfile);
    connect(logoutButton, &QPushButton::clicked, this, &ClientWindow::logout);
    
    leftLayout->addWidget(friendsButton);
    leftLayout->addWidget(profileButton);
    leftLayout->addWidget(logoutButton);
    
    rightPanel = new QWidget(this);
    QVBoxLayout* rightLayout = new QVBoxLayout(rightPanel);
    rightLayout->setContentsMargins(10, 10, 10, 10);
    rightLayout->setSpacing(5);
    
    QHBoxLayout* filterLayout = new QHBoxLayout();
    QLabel* filterLabel = new QLabel("Фильтр:", rightPanel);
    filterCombo = new QComboBox(rightPanel);
    filterCombo->addItems({"Все сообщения", "Публичные", "Приватные"});
    connect(filterCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onMessageTypeChanged()));
    
    searchInput = new QLineEdit(rightPanel);
    searchInput->setPlaceholderText("Поиск...");
    connect(searchInput, &QLineEdit::textChanged, this, &ClientWindow::onSearchTextChanged);
    
    filterLayout->addWidget(filterLabel);
    filterLayout->addWidget(filterCombo);
    filterLayout->addStretch();
    filterLayout->addWidget(searchInput);
    rightLayout->addLayout(filterLayout);
    
    messagesDisplay = new QTextEdit(rightPanel);
    messagesDisplay->setReadOnly(true);
    messagesDisplay->setStyleSheet("background-color: #fafafa; border: 1px solid #ddd; border-radius: 5px;");
    rightLayout->addWidget(messagesDisplay, 2);
    
    QHBoxLayout* messageTypeLayout = new QHBoxLayout();
    QLabel* typeLabel = new QLabel("Тип:", rightPanel);
    messageTypeCombo = new QComboBox(rightPanel);
    messageTypeCombo->addItems({"Публичное", "Приватное"});
    messageTypeLayout->addWidget(typeLabel);
    messageTypeLayout->addWidget(messageTypeCombo);
    messageTypeLayout->addStretch();
    
    QHBoxLayout* inputLayout = new QHBoxLayout();
    messageInput = new QLineEdit(rightPanel);
    messageInput->setPlaceholderText("Введите сообщение...");
    messageInput->installEventFilter(this);
    
    sendButton = new QPushButton("Отправить", rightPanel);
    sendButton->setMinimumWidth(100);
    connect(sendButton, &QPushButton::clicked, this, &ClientWindow::sendMessage);
    connect(messageInput, &QLineEdit::returnPressed, this, &ClientWindow::sendMessage);
    
    inputLayout->addWidget(messageInput, 3);
    inputLayout->addWidget(sendButton, 1);
    
    rightLayout->addLayout(messageTypeLayout);
    rightLayout->addLayout(inputLayout);
    
    mainSplitter->addWidget(leftPanel);
    mainSplitter->addWidget(rightPanel);
    mainSplitter->setStretchFactor(0, 0);
    mainSplitter->setStretchFactor(1, 1);
    
    mainLayout->addWidget(mainSplitter);
    
    setWindowTitle("STL Chat - Клиент");
    resize(1000, 700);
    
    ConnectionDialog connDialog(this);
    if (connDialog.exec() == QDialog::Accepted) {
        QString host = connDialog.getHost();
        uint16_t port = connDialog.getPort();
        
        chat = new Chat();
        if (chat->connectToServer(host.toStdString(), port)) {
            AuthDialog authDialog(this);
            if (authDialog.exec() == QDialog::Accepted) {
                QString login = authDialog.getLogin();
                QString password = authDialog.getPassword();
                
                if (authDialog.isRegistration()) {
                    QString name = authDialog.getName();
                    std::string request = "REGISTER\n" + login.toStdString() + "\n" + 
                                        password.toStdString() + "\n" + 
                                        (name.isEmpty() ? login.toStdString() : name.toStdString());
                    std::string response = chat->sendRequestToServer(request);
                    
                    std::string status, data;
                    if (chat->parseServerResponse(response, status, data)) {
                        if (status == "SUCCESS") {
                            QMessageBox::information(this, "Успех", "Регистрация успешна!");
                        } else {
                            showErrorMessage("Ошибка регистрации: " + QString::fromStdString(data));
                            delete chat;
                            chat = nullptr;
                            close();
                            return;
                        }
                    }
                }
                
                std::string request = "LOGIN\n" + login.toStdString() + "\n" + password.toStdString();
                std::string response = chat->sendRequestToServer(request);
                
                std::string status, data;
                if (chat->parseServerResponse(response, status, data)) {
                    if (status == "SUCCESS") {
                        size_t usersPos = data.find("USERS:");
                        size_t messagesPos = data.find("MESSAGES:");
                        
                        if (usersPos != std::string::npos && messagesPos != std::string::npos) {
                            std::string usersData = data.substr(usersPos + 6, messagesPos - usersPos - 6);
                            std::string messagesData = data.substr(messagesPos + 9);
                            
                            chat->loadUsersFromServer(usersData);
                            chat->loadMessagesFromServer(messagesData);
                        }
                        
                        auto users = chat->getUsers();
                        auto it = users.find(login.toStdString());
                        if (it != users.end()) {
                            chat->setCurrentUser(&(it->second));
                            if (chat->getCurrentUser()) {
                                chat->getCurrentUser()->setOnlineStatus(true);
                                chat->addOnlineUser(login.toStdString());
                                
                                userInfoLabel->setText(QString::fromStdString(chat->getCurrentUser()->getName()) + "\n(" + login + ")");
                                
                                try {
                                    updateUsersList();
                                    updateMessagesDisplay();
                                    refreshTimer->start(3000);
                                    show();
                                    raise();
                                    activateWindow();
                                } catch (const std::exception& e) {
                                    showErrorMessage("Ошибка при обновлении интерфейса: " + QString::fromStdString(e.what()));
                                } catch (...) {
                                    showErrorMessage("Ошибка при обновлении интерфейса!");
                                }
                            } else {
                                showErrorMessage("Ошибка: не удалось установить текущего пользователя!");
                                delete chat;
                                chat = nullptr;
                                close();
                                return;
                            }
                        } else {
                            showErrorMessage("Не удалось загрузить данные пользователя! Пользователь не найден в списке.");
                            delete chat;
                            chat = nullptr;
                            close();
                            return;
                        }
                    } else {
                        showErrorMessage("Неверный логин или пароль: " + QString::fromStdString(data));
                        delete chat;
                        chat = nullptr;
                        close();
                        return;
                    }
                } else {
                    showErrorMessage("Ошибка связи с сервером! Ответ: " + QString::fromStdString(response));
                    delete chat;
                    chat = nullptr;
                    close();
                    return;
                }
            } else {
                delete chat;
                chat = nullptr;
                close();
                return;
            }
        } else {
            showErrorMessage("Не удалось подключиться к серверу!");
            close();
            return;
        }
    } else {
        close();
        return;
    }
    
    updateUsersList();
}

void ClientWindow::setupStyles() {
    setStyleSheet(
        "QMainWindow { background-color: #f5f5f5; }"
        "QPushButton {"
        "    background-color: #2196F3;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 5px;"
        "    padding: 8px 15px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover { background-color: #1976D2; }"
        "QPushButton:pressed { background-color: #0D47A1; }"
        "QListWidget {"
        "    border: 1px solid #ddd;"
        "    border-radius: 5px;"
        "    background-color: white;"
        "}"
        "QListWidget::item { padding: 5px; }"
        "QListWidget::item:selected { background-color: #2196F3; color: white; }"
        "QLineEdit, QComboBox {"
        "    border: 2px solid #ddd;"
        "    border-radius: 4px;"
        "    padding: 5px;"
        "    background-color: white;"
        "}"
        "QLineEdit:focus, QComboBox:focus { border-color: #2196F3; }"
    );
}

void ClientWindow::updateUsersList() {
    if (!chat) return;
    
    usersList->clear();
    auto users = chat->getUsers();
    auto onlineUsers = chat->getOnlineUsers();
    
    for (const auto& pair : users) {
        QString login = QString::fromStdString(pair.first);
        QString name = QString::fromStdString(pair.second.getName());
        bool isOnline = chat->isUserOnline(pair.first);
        
        QString itemText = name + " (" + login + ")";
        if (isOnline) {
            itemText += " 🟢";
        }
        
        QListWidgetItem* item = new QListWidgetItem(itemText);
        if (isOnline) {
            item->setForeground(QColor(76, 175, 80));
        }
        usersList->addItem(item);
    }
}

void ClientWindow::updateMessagesDisplay() {
    if (!chat || !chat->getCurrentUser()) {
        messagesDisplay->setHtml("<p>Нет сообщений для отображения</p>");
        return;
    }
    
    QString searchText = searchInput->text().toLower();
    int filterIndex = filterCombo->currentIndex();
    
    QString html;
    try {
        auto userMessages = chat->getMessagesForCurrentUser();
        
        for (const auto& msg : userMessages) {
        if (!searchText.isEmpty()) {
            QString msgText = QString::fromStdString(msg.getText());
            if (!msgText.toLower().contains(searchText)) {
                continue;
            }
        }
        
        MessageType type = msg.getType();
        if (filterIndex == 1 && type != MessageType::PUBLIC) continue;
        if (filterIndex == 2 && type != MessageType::PRIVATE) continue;
        
        QString senderName = msg.getSender() ? QString::fromStdString(msg.getSender()->getName()) : "System";
        QString recipientName = msg.getRecipient() ? QString::fromStdString(msg.getRecipient()->getName()) : "";
        QString text = QString::fromStdString(msg.getText());
        
        QString color = "#333";
        QString prefix = "";
        if (type == MessageType::PRIVATE) {
            color = "#9c27b0";
            prefix = "🔒 ";
        } else if (type == MessageType::SYSTEM) {
            color = "#ff9800";
            prefix = "ℹ️ ";
        }
        
        html += QString("<div style='color: %1; margin: 5px 0; padding: 5px; border-left: 3px solid %1;'>")
                    .arg(color);
        if (type == MessageType::PRIVATE && !recipientName.isEmpty()) {
            html += QString("<b>%1 → %2:</b> ").arg(prefix + senderName, recipientName);
        } else {
            html += QString("<b>%1%2:</b> ").arg(prefix, senderName);
        }
            html += QString("%1").arg(text.toHtmlEscaped());
            html += "</div>";
        }
        
        messagesDisplay->setHtml(html);
        QScrollBar* scrollBar = messagesDisplay->verticalScrollBar();
        if (scrollBar) {
            scrollBar->setValue(scrollBar->maximum());
        }
    } catch (const std::exception& e) {
        messagesDisplay->setHtml("<p style='color: red;'>Ошибка при отображении сообщений: " + QString::fromStdString(e.what()) + "</p>");
    } catch (...) {
        messagesDisplay->setHtml("<p style='color: red;'>Ошибка при отображении сообщений</p>");
    }
}

void ClientWindow::refreshMessages() {
    if (!chat || !chat->isConnected() || !chat->getCurrentUser()) return;
    
    std::string request = "GET_MESSAGES\n" + chat->getCurrentUser()->getLogin();
    std::string response = chat->sendRequestToServer(request);
    
    std::string status, data;
    if (chat->parseServerResponse(response, status, data)) {
        if (status == "SUCCESS") {
            chat->loadMessagesFromServer(data);
            updateMessagesDisplay();
        }
    }
    
    request = "GET_USERS";
    response = chat->sendRequestToServer(request);
    if (chat->parseServerResponse(response, status, data)) {
        if (status == "SUCCESS") {
            chat->loadUsersFromServer(data);
            updateUsersList();
        }
    }
}

void ClientWindow::sendMessage() {
    if (!chat || !chat->getCurrentUser()) return;
    
    QString text = messageInput->text().trimmed();
    if (text.isEmpty()) return;
    
    int messageType = messageTypeCombo->currentIndex();
    std::string recipient = "";
    
    if (messageType == 1) {
        if (currentSelectedUser.isEmpty()) {
            QMessageBox::warning(this, "Ошибка", "Выберите получателя из списка пользователей!");
            return;
        }
        recipient = currentSelectedUser.toStdString();
    }
    
    std::string request = "SEND_MESSAGE\n" + 
                         chat->getCurrentUser()->getLogin() + "\n" + 
                         recipient + "\n" + 
                         text.toStdString() + "\n" + 
                         (messageType == 0 ? "PUBLIC" : "PRIVATE");
    
    std::string response = chat->sendRequestToServer(request);
    
    std::string status, data;
    if (chat->parseServerResponse(response, status, data)) {
        if (status == "SUCCESS") {
            messageInput->clear();
            refreshMessages();
        } else {
            showErrorMessage("Ошибка отправки: " + QString::fromStdString(data));
        }
    }
}

void ClientWindow::onUserSelected() {
    QListWidgetItem* item = usersList->currentItem();
    if (item) {
        QString text = item->text();
        int parenPos = text.indexOf('(');
        if (parenPos > 0) {
            int endParen = text.indexOf(')', parenPos);
            if (endParen > parenPos) {
                currentSelectedUser = text.mid(parenPos + 1, endParen - parenPos - 1);
                messageTypeCombo->setCurrentIndex(1);
            }
        }
    }
}

void ClientWindow::sendPrivateMessage() {
    sendMessage();
}

void ClientWindow::onSearchTextChanged() {
    updateMessagesDisplay();
}

void ClientWindow::onMessageTypeChanged() {
    updateMessagesDisplay();
}

void ClientWindow::logout() {
    if (chat) {
        chat->logout();
        chat->disconnectFromServer();
        delete chat;
        chat = nullptr;
    }
    close();
}

void ClientWindow::showProfile() {
    if (!chat || !chat->getCurrentUser()) {
        QMessageBox::information(this, "Профиль", "Не авторизован");
        return;
    }
    
    QString profile = QString("Имя: %1\nЛогин: %2\nДрузья: %3\nСообщений отправлено: %4")
        .arg(QString::fromStdString(chat->getCurrentUser()->getName()))
        .arg(QString::fromStdString(chat->getCurrentUser()->getLogin()))
        .arg(chat->getCurrentUser()->getFriendCount())
        .arg(chat->getMessageCount());
    
    QMessageBox::information(this, "Профиль", profile);
}

void ClientWindow::manageFriends() {
    QMessageBox::information(this, "Друзья", "Функция управления друзьями в разработке");
}

void ClientWindow::showErrorMessage(const QString& message) {
    QMessageBox::critical(this, "Ошибка", message);
}

bool ClientWindow::eventFilter(QObject* obj, QEvent* event) {
    if (obj == messageInput && event->type() == QEvent::KeyPress) {
        QKeyEvent* keyEvent = static_cast<QKeyEvent*>(event);
        if (keyEvent->key() == Qt::Key_Return || keyEvent->key() == Qt::Key_Enter) {
            sendMessage();
            return true;
        }
    }
    return QMainWindow::eventFilter(obj, event);
}

