#ifndef CONNECTIONDIALOG_H
#define CONNECTIONDIALOG_H

#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>

class ConnectionDialog : public QDialog {
    Q_OBJECT

public:
    explicit ConnectionDialog(QWidget *parent = nullptr);
    QString getHost() const { return hostInput->text(); }
    uint16_t getPort() const { return portInput->text().toUShort(); }

private slots:
    void onConnectClicked();
    void onCancelClicked();

private:
    QLineEdit* hostInput;
    QLineEdit* portInput;
};

#endif

