#ifndef SERVERWINDOW_H
#define SERVERWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QTableWidget>
#include <QTextEdit>
#include <QLabel>
#include <QLineEdit>
#include <QTimer>
#include <QHeaderView>
#include <QMessageBox>
#include <QGroupBox>
#include <QComboBox>
#include <QSpinBox>
#include <QStatusBar>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QStyleFactory>
#include <QApplication>
#include <QHeaderView>
#include <QTableWidgetItem>
#include <QDateTime>
#include <QColor>
#include <QPalette>
#include <QScrollBar>
#include <QAbstractItemView>
#include "server.h"

class ServerWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit ServerWindow(QWidget *parent = nullptr);
    ~ServerWindow();

private slots:
    void startServer();
    void stopServer();
    void refreshData();
    void banSelectedUser();
    void unbanSelectedUser();
    void disconnectSelectedUser();
    void filterMessages();
    void filterUsers();

private:
    void setupUI();
    void setupStyles();
    void updateMessagesTable();
    void updateUsersTable();
    void updateStatistics();
    void showMessage(const QString& message, bool isError = false);


    QWidget* centralWidget;
    QVBoxLayout* mainLayout;


    QGroupBox* serverControlGroup;
    QHBoxLayout* serverControlLayout;
    QLineEdit* portInput;
    QPushButton* startButton;
    QPushButton* stopButton;
    QPushButton* refreshButton;
    QLabel* statusLabel;


    QGroupBox* statsGroup;
    QHBoxLayout* statsLayout;
    QLabel* totalUsersLabel;
    QLabel* onlineUsersLabel;
    QLabel* totalMessagesLabel;
    QLabel* bannedUsersLabel;


    QGroupBox* messagesGroup;
    QVBoxLayout* messagesLayout;
    QComboBox* messageFilterCombo;
    QTableWidget* messagesTable;


    QGroupBox* usersGroup;
    QVBoxLayout* usersLayout;
    QComboBox* userFilterCombo;
    QTableWidget* usersTable;
    QPushButton* banButton;
    QPushButton* unbanButton;
    QPushButton* disconnectButton;


    Server* server;
    QTimer* refreshTimer;
    bool serverRunning;
    uint16_t currentPort;
};

#endif

