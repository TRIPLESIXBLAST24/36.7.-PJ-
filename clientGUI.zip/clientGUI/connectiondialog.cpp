#include "connectiondialog.h"
#include <QIntValidator>

ConnectionDialog::ConnectionDialog(QWidget *parent)
    : QDialog(parent) {
    setWindowTitle("Подключение к серверу");
    setModal(true);
    resize(400, 200);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(20, 20, 20, 20);
    
    QLabel* titleLabel = new QLabel("STL Chat - Подключение к серверу", this);
    titleLabel->setStyleSheet("font-size: 16pt; font-weight: bold; color: #2196F3;");
    mainLayout->addWidget(titleLabel);
    
    mainLayout->addSpacing(10);
    
    QLabel* hostLabel = new QLabel("Адрес сервера:", this);
    hostInput = new QLineEdit("127.0.0.1", this);
    hostInput->setPlaceholderText("localhost или IP-адрес");
    mainLayout->addWidget(hostLabel);
    mainLayout->addWidget(hostInput);
    
    QLabel* portLabel = new QLabel("Порт:", this);
    portInput = new QLineEdit("8080", this);
    portInput->setValidator(new QIntValidator(1, 65535, this));
    portInput->setPlaceholderText("8080");
    mainLayout->addWidget(portLabel);
    mainLayout->addWidget(portInput);
    
    mainLayout->addStretch();
    
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    QPushButton* connectButton = new QPushButton("Подключиться", this);
    QPushButton* cancelButton = new QPushButton("Отмена", this);
    
    connectButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #2196F3;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 5px;"
        "    padding: 10px 20px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover { background-color: #1976D2; }"
    );
    
    cancelButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #f44336;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 5px;"
        "    padding: 10px 20px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover { background-color: #d32f2f; }"
    );
    
    buttonLayout->addStretch();
    buttonLayout->addWidget(connectButton);
    buttonLayout->addWidget(cancelButton);
    mainLayout->addLayout(buttonLayout);
    
    connect(connectButton, &QPushButton::clicked, this, &ConnectionDialog::onConnectClicked);
    connect(cancelButton, &QPushButton::clicked, this, &ConnectionDialog::onCancelClicked);
    
    hostInput->setFocus();
}

void ConnectionDialog::onConnectClicked() {
    if (hostInput->text().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Введите адрес сервера!");
        return;
    }
    
    bool ok;
    uint16_t port = portInput->text().toUShort(&ok);
    if (!ok || port == 0) {
        QMessageBox::warning(this, "Ошибка", "Неверный номер порта!");
        return;
    }
    
    accept();
}

void ConnectionDialog::onCancelClicked() {
    reject();
}

