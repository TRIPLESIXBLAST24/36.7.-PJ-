#ifndef AUTHDIALOG_H
#define AUTHDIALOG_H

#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QStackedWidget>
#include <QRadioButton>

class AuthDialog : public QDialog {
    Q_OBJECT

public:
    explicit AuthDialog(QWidget *parent = nullptr);
    
    QString getLogin() const;
    QString getPassword() const;
    QString getName() const;
    bool isRegistration() const { return isRegisterMode; }

private slots:
    void onModeChanged();
    void onOkClicked();
    void onCancelClicked();

private:
    QStackedWidget* stackWidget;
    QRadioButton* loginRadio;
    QRadioButton* registerRadio;
    
    QLineEdit* loginInput;
    QLineEdit* passwordInput;
    QLineEdit* registerLoginInput;
    QLineEdit* registerPasswordInput;
    QLineEdit* nameInput;
    
    bool isRegisterMode;
};

#endif

