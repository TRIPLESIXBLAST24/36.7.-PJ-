#include "serverwindow.h"
#include <QHeaderView>
#include <QDateTime>
#include <QColor>
#include <QPalette>
#include <QScrollBar>
#include <QAbstractItemView>
#include <QStandardPaths>
#include <QDir>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <string>

ServerWindow::ServerWindow(QWidget *parent)
    : QMainWindow(parent), server(nullptr), serverRunning(false), currentPort(8080) {
    setupUI();
    setupStyles();

    refreshTimer = new QTimer(this);
    connect(refreshTimer, &QTimer::timeout, this, &ServerWindow::refreshData);
}

ServerWindow::~ServerWindow() {
    if (server && server->isRunning()) {
        server->stop();
    }
    delete server;
}

void ServerWindow::setupUI() {
    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(15, 15, 15, 15);


    serverControlGroup = new QGroupBox("Управление сервером", this);
    serverControlLayout = new QHBoxLayout(serverControlGroup);

    QLabel* portLabel = new QLabel("Порт:", this);
    portInput = new QLineEdit("8080", this);
    portInput->setMaximumWidth(100);

    startButton = new QPushButton("▶ Запустить сервер", this);
    startButton->setMinimumHeight(35);
    stopButton = new QPushButton("⏹ Остановить сервер", this);
    stopButton->setMinimumHeight(35);
    stopButton->setEnabled(false);

    refreshButton = new QPushButton("🔄 Обновить", this);
    refreshButton->setMinimumHeight(35);

    statusLabel = new QLabel("Сервер остановлен", this);
    statusLabel->setStyleSheet("font-weight: bold; color: #d32f2f;");

    serverControlLayout->addWidget(portLabel);
    serverControlLayout->addWidget(portInput);
    serverControlLayout->addWidget(startButton);
    serverControlLayout->addWidget(stopButton);
    serverControlLayout->addWidget(refreshButton);
    serverControlLayout->addStretch();
    serverControlLayout->addWidget(statusLabel);

    connect(startButton, &QPushButton::clicked, this, &ServerWindow::startServer);
    connect(stopButton, &QPushButton::clicked, this, &ServerWindow::stopServer);
    connect(refreshButton, &QPushButton::clicked, this, &ServerWindow::refreshData);


    statsGroup = new QGroupBox("Статистика", this);
    statsLayout = new QHBoxLayout(statsGroup);

    totalUsersLabel = new QLabel("Всего пользователей: 0", this);
    onlineUsersLabel = new QLabel("Онлайн: 0", this);
    totalMessagesLabel = new QLabel("Всего сообщений: 0", this);
    bannedUsersLabel = new QLabel("Забанено: 0", this);

    statsLayout->addWidget(totalUsersLabel);
    statsLayout->addWidget(onlineUsersLabel);
    statsLayout->addWidget(totalMessagesLabel);
    statsLayout->addWidget(bannedUsersLabel);
    statsLayout->addStretch();


    messagesGroup = new QGroupBox("Все сообщения", this);
    messagesLayout = new QVBoxLayout(messagesGroup);

    QHBoxLayout* messageFilterLayout = new QHBoxLayout();
    messageFilterLayout->addWidget(new QLabel("Фильтр:", this));
    messageFilterCombo = new QComboBox(this);
    messageFilterCombo->addItems({"Все", "Публичные", "Приватные", "Системные"});
    messageFilterLayout->addWidget(messageFilterCombo);
    messageFilterLayout->addStretch();
    connect(messageFilterCombo, SIGNAL(currentIndexChanged(int)),
            this, SLOT(filterMessages()));

    messagesTable = new QTableWidget(this);
    messagesTable->setColumnCount(5);
    messagesTable->setHorizontalHeaderLabels({"Время", "Отправитель", "Получатель", "Тип", "Сообщение"});
    messagesTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    messagesTable->setSelectionMode(QAbstractItemView::SingleSelection);
    messagesTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    messagesTable->setAlternatingRowColors(true);
    messagesTable->verticalHeader()->setVisible(false);
    messagesTable->horizontalHeader()->setStretchLastSection(true);
    messagesTable->setColumnWidth(0, 150);
    messagesTable->setColumnWidth(1, 120);
    messagesTable->setColumnWidth(2, 120);
    messagesTable->setColumnWidth(3, 100);

    messagesLayout->addLayout(messageFilterLayout);
    messagesLayout->addWidget(messagesTable);


    usersGroup = new QGroupBox("Пользователи", this);
    usersLayout = new QVBoxLayout(usersGroup);

    QHBoxLayout* userFilterLayout = new QHBoxLayout();
    userFilterLayout->addWidget(new QLabel("Фильтр:", this));
    userFilterCombo = new QComboBox(this);
    userFilterCombo->addItems({"Все", "Онлайн", "Офлайн", "Забаненные"});
    userFilterLayout->addWidget(userFilterCombo);
    userFilterLayout->addStretch();
    connect(userFilterCombo, SIGNAL(currentIndexChanged(int)),
            this, SLOT(filterUsers()));

    usersTable = new QTableWidget(this);
    usersTable->setColumnCount(4);
    usersTable->setHorizontalHeaderLabels({"Логин", "Имя", "Статус", "Статус бана"});
    usersTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    usersTable->setSelectionMode(QAbstractItemView::SingleSelection);
    usersTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    usersTable->setAlternatingRowColors(true);
    usersTable->verticalHeader()->setVisible(false);
    usersTable->horizontalHeader()->setStretchLastSection(true);
    usersTable->setColumnWidth(0, 150);
    usersTable->setColumnWidth(1, 150);
    usersTable->setColumnWidth(2, 100);
    usersTable->setColumnWidth(3, 120);

    QHBoxLayout* userActionsLayout = new QHBoxLayout();
    banButton = new QPushButton("🚫 Забанить", this);
    unbanButton = new QPushButton("✅ Разбанить", this);
    disconnectButton = new QPushButton("🔌 Отключить", this);

    userActionsLayout->addWidget(banButton);
    userActionsLayout->addWidget(unbanButton);
    userActionsLayout->addWidget(disconnectButton);
    userActionsLayout->addStretch();

    connect(banButton, &QPushButton::clicked, this, &ServerWindow::banSelectedUser);
    connect(unbanButton, &QPushButton::clicked, this, &ServerWindow::unbanSelectedUser);
    connect(disconnectButton, &QPushButton::clicked, this, &ServerWindow::disconnectSelectedUser);

    usersLayout->addLayout(userFilterLayout);
    usersLayout->addWidget(usersTable);
    usersLayout->addLayout(userActionsLayout);


    mainLayout->addWidget(serverControlGroup);
    mainLayout->addWidget(statsGroup);
    mainLayout->addWidget(messagesGroup, 2);
    mainLayout->addWidget(usersGroup, 1);

    setWindowTitle("STL Chat Server - Панель управления");
    resize(1200, 800);
}

void ServerWindow::setupStyles() {
    setStyleSheet(
        "QMainWindow {"
        "    background-color: #f5f5f5;"
        "}"
        "QGroupBox {"
        "    font-weight: bold;"
        "    font-size: 12pt;"
        "    border: 2px solid #2196F3;"
        "    border-radius: 8px;"
        "    margin-top: 10px;"
        "    padding-top: 15px;"
        "    background-color: white;"
        "}"
        "QGroupBox::title {"
        "    subcontrol-origin: margin;"
        "    left: 10px;"
        "    padding: 0 5px;"
        "}"
        "QPushButton {"
        "    background-color: #2196F3;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 5px;"
        "    padding: 8px 15px;"
        "    font-weight: bold;"
        "    min-width: 100px;"
        "}"
        "QPushButton:hover {"
        "    background-color: #1976D2;"
        "}"
        "QPushButton:pressed {"
        "    background-color: #0D47A1;"
        "}"
        "QPushButton:disabled {"
        "    background-color: #cccccc;"
        "    color: #666666;"
        "}"
        "QPushButton#banButton {"
        "    background-color: #f44336;"
        "}"
        "QPushButton#banButton:hover {"
        "    background-color: #d32f2f;"
        "}"
        "QTableWidget {"
        "    border: 1px solid #ddd;"
        "    border-radius: 5px;"
        "    background-color: white;"
        "    gridline-color: #e0e0e0;"
        "}"
        "QTableWidget::item {"
        "    padding: 5px;"
        "}"
        "QTableWidget::item:selected {"
        "    background-color: #2196F3;"
        "    color: white;"
        "}"
        "QHeaderView::section {"
        "    background-color: #2196F3;"
        "    color: white;"
        "    padding: 8px;"
        "    border: none;"
        "    font-weight: bold;"
        "}"
        "QLineEdit, QComboBox {"
        "    border: 2px solid #ddd;"
        "    border-radius: 4px;"
        "    padding: 5px;"
        "    background-color: white;"
        "}"
        "QLineEdit:focus, QComboBox:focus {"
        "    border-color: #2196F3;"
        "}"
        "QLabel {"
        "    color: #333;"
        "}"
    );

    banButton->setObjectName("banButton");
}

void ServerWindow::startServer() {
    bool ok;
    uint16_t port = portInput->text().toUShort(&ok);
    if (!ok || port == 0) {
        showMessage("Неверный номер порта!", true);
        return;
    }

    if (server && server->isRunning()) {
        showMessage("Сервер уже запущен!", true);
        return;
    }

    delete server;


    QString appData = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (appData.isEmpty())
        appData = QDir::homePath() + "/.stlchat_server";
    QString dbDir = appData + "/chat.db";
    QDir().mkpath(dbDir);
    std::string dbPath = dbDir.toStdString();
    server = new Server(port, dbPath);

    if (server->start()) {
        serverRunning = true;
        currentPort = port;
        startButton->setEnabled(false);
        stopButton->setEnabled(true);
        portInput->setEnabled(false);
        statusLabel->setText("Сервер запущен на порту " + QString::number(port));
        statusLabel->setStyleSheet("font-weight: bold; color: #4caf50;");

        refreshTimer->start(2000);
        refreshData();
        showMessage("Сервер успешно запущен!", false);
    } else {
        QString err = QString::fromStdString(server->getLastError());
        showMessage("Не удалось запустить сервер!\n\n" + (err.isEmpty() ? "Неизвестная ошибка." : err), true);
        delete server;
        server = nullptr;
    }
}

void ServerWindow::stopServer() {
    if (server && server->isRunning()) {
        server->stop();
        serverRunning = false;
        startButton->setEnabled(true);
        stopButton->setEnabled(false);
        portInput->setEnabled(true);
        statusLabel->setText("Сервер остановлен");
        statusLabel->setStyleSheet("font-weight: bold; color: #d32f2f;");

        refreshTimer->stop();
        showMessage("Сервер остановлен", false);
    }
}

void ServerWindow::refreshData() {
    if (!server || !server->isRunning()) {
        return;
    }

    updateMessagesTable();
    updateUsersTable();
    updateStatistics();
}

void ServerWindow::updateMessagesTable() {
    if (!server || !server->isRunning()) {
        messagesTable->setRowCount(0);
        return;
    }

    vector<MessageData> allMessages = server->getAllMessages();
    int filterIndex = messageFilterCombo->currentIndex();

    messagesTable->setRowCount(0);

    for (const auto& msg : allMessages) {

        if (filterIndex == 1 && msg.type != "PUBLIC") continue;
        if (filterIndex == 2 && msg.type != "PRIVATE") continue;
        if (filterIndex == 3 && msg.type != "SYSTEM") continue;

        int row = messagesTable->rowCount();
        messagesTable->insertRow(row);


        QDateTime dateTime = QDateTime::fromMSecsSinceEpoch(msg.timestamp);
        QString timeStr = dateTime.toString("hh:mm:ss dd.MM.yyyy");

        messagesTable->setItem(row, 0, new QTableWidgetItem(timeStr));
        messagesTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(msg.senderLogin)));
        messagesTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(msg.recipientLogin)));
        messagesTable->setItem(row, 3, new QTableWidgetItem(QString::fromStdString(msg.type)));
        messagesTable->setItem(row, 4, new QTableWidgetItem(QString::fromStdString(msg.text)));


        QColor rowColor;
        if (msg.type == "PRIVATE") {
            rowColor = QColor(255, 240, 240);
        } else if (msg.type == "SYSTEM") {
            rowColor = QColor(240, 255, 240);
        } else {
            rowColor = QColor(240, 248, 255);
        }

        for (int col = 0; col < 5; ++col) {
            QTableWidgetItem* item = messagesTable->item(row, col);
            if (item) {
                item->setBackground(rowColor);
            }
        }
    }
}

void ServerWindow::updateUsersTable() {
    if (!server || !server->isRunning()) {
        usersTable->setRowCount(0);
        return;
    }

    vector<UserData> allUsers = server->getAllUsersData();
    set<string> onlineUsers = server->getOnlineUsers();
    int filterIndex = userFilterCombo->currentIndex();

    usersTable->setRowCount(0);

    for (const auto& user : allUsers) {
        bool isOnline = onlineUsers.find(user.login) != onlineUsers.end();
        bool isBanned = server->isUserBanned(user.login);


        if (filterIndex == 1 && !isOnline) continue;
        if (filterIndex == 2 && isOnline) continue;
        if (filterIndex == 3 && !isBanned) continue;

        int row = usersTable->rowCount();
        usersTable->insertRow(row);

        usersTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(user.login)));
        usersTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(user.name)));
        usersTable->setItem(row, 2, new QTableWidgetItem(isOnline ? "Онлайн" : "Офлайн"));
        usersTable->setItem(row, 3, new QTableWidgetItem(isBanned ? "Забанен" : "Активен"));


        QColor rowColor;
        if (isBanned) {
            rowColor = QColor(255, 235, 238);
        } else if (isOnline) {
            rowColor = QColor(232, 245, 233);
        } else {
            rowColor = QColor(250, 250, 250);
        }

        for (int col = 0; col < 4; ++col) {
            QTableWidgetItem* item = usersTable->item(row, col);
            if (item) {
                item->setBackground(rowColor);
            }
        }
    }
}

void ServerWindow::updateStatistics() {
    if (!server || !server->isRunning()) {
        totalUsersLabel->setText("Всего пользователей: 0");
        onlineUsersLabel->setText("Онлайн: 0");
        totalMessagesLabel->setText("Всего сообщений: 0");
        bannedUsersLabel->setText("Забанено: 0");
        return;
    }

    vector<UserData> allUsers = server->getAllUsersData();
    set<string> onlineUsers = server->getOnlineUsers();
    vector<MessageData> allMessages = server->getAllMessages();

    int bannedCount = 0;
    for (const auto& user : allUsers) {
        if (server->isUserBanned(user.login)) {
            bannedCount++;
        }
    }

    totalUsersLabel->setText("Всего пользователей: " + QString::number(allUsers.size()));
    onlineUsersLabel->setText("Онлайн: " + QString::number(onlineUsers.size()));
    totalMessagesLabel->setText("Всего сообщений: " + QString::number(allMessages.size()));
    bannedUsersLabel->setText("Забанено: " + QString::number(bannedCount));
}

void ServerWindow::banSelectedUser() {
    int row = usersTable->currentRow();
    if (row < 0) {
        showMessage("Выберите пользователя для бана!", true);
        return;
    }

    QString login = usersTable->item(row, 0)->text();

    if (server && server->banUser(login.toStdString())) {
        showMessage("Пользователь " + login + " забанен", false);
        refreshData();
    } else {
        showMessage("Не удалось забанить пользователя!", true);
    }
}

void ServerWindow::unbanSelectedUser() {
    int row = usersTable->currentRow();
    if (row < 0) {
        showMessage("Выберите пользователя для разбана!", true);
        return;
    }

    QString login = usersTable->item(row, 0)->text();

    if (server && server->unbanUser(login.toStdString())) {
        showMessage("Пользователь " + login + " разбанен", false);
        refreshData();
    } else {
        showMessage("Не удалось разбанить пользователя!", true);
    }
}

void ServerWindow::disconnectSelectedUser() {
    int row = usersTable->currentRow();
    if (row < 0) {
        showMessage("Выберите пользователя для отключения!", true);
        return;
    }

    QString login = usersTable->item(row, 0)->text();

    if (server && server->disconnectUser(login.toStdString())) {
        showMessage("Пользователь " + login + " отключен", false);
        refreshData();
    } else {
        showMessage("Не удалось отключить пользователя или пользователь не подключен!", true);
    }
}

void ServerWindow::filterMessages() {
    updateMessagesTable();
}

void ServerWindow::filterUsers() {
    updateUsersTable();
}

void ServerWindow::showMessage(const QString& message, bool isError) {
    QMessageBox msgBox(this);
    msgBox.setText(message);
    msgBox.setIcon(isError ? QMessageBox::Critical : QMessageBox::Information);
    msgBox.setWindowTitle(isError ? "Ошибка" : "Информация");
    msgBox.exec();
}

